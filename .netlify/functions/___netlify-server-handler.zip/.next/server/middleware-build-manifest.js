globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/465f799faf41e6df.js",
    "static/chunks/38cb1589c99e9c99.js",
    "static/chunks/8ff76c3c792e6ee4.js",
    "static/chunks/bacf5a910dcf2b3b.js",
    "static/chunks/turbopack-9564312cffce5a96.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];