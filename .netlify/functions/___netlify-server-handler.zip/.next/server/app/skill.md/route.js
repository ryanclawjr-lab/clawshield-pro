var R=require("../../chunks/[turbopack]_runtime.js")("server/app/skill.md/route.js")
R.c("server/chunks/[root-of-the-server]__91db3007._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_skill_md_route_actions_646f355a.js")
R.m(31069)
module.exports=R.m(31069).exports
