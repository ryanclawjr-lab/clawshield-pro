var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/agent-auth/[[...fishnet-auth]]/route.js")
R.c("server/chunks/[root-of-the-server]__1dab85da._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/ce889_server_app_api_agent-auth_[[___fishnet-auth]]_route_actions_beb8229a.js")
R.m(41852)
module.exports=R.m(41852).exports
