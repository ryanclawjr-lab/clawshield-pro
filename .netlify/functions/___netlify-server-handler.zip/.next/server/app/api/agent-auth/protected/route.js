var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/agent-auth/protected/route.js")
R.c("server/chunks/[root-of-the-server]__fd5bdacb._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_agent-auth_protected_route_actions_a6ddd8b5.js")
R.m(98443)
module.exports=R.m(98443).exports
