var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/health/route.js")
R.c("server/chunks/[root-of-the-server]__4e7aa9ab._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_health_route_actions_da3433c4.js")
R.m(43007)
module.exports=R.m(43007).exports
