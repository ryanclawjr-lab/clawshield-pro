var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/sessions/[sessionId]/state/route.js")
R.c("server/chunks/[root-of-the-server]__1cb04e88._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_sessions_[sessionId]_state_route_actions_54abc071.js")
R.m(2287)
module.exports=R.m(2287).exports
