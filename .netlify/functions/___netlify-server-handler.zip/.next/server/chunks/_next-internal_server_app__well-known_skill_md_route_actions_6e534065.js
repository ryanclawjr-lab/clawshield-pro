module.exports=[98191,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app__well-known_skill_md_route_actions_6e534065.js.map