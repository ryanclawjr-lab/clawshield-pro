module.exports=[98674,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_demo_solve_route_actions_9a0cec61.js.map