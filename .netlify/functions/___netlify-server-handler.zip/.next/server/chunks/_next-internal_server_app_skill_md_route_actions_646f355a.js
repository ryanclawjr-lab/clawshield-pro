module.exports=[29853,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_skill_md_route_actions_646f355a.js.map