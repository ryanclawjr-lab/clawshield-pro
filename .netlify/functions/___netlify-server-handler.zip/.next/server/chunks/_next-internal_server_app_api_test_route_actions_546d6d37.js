module.exports=[70776,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_test_route_actions_546d6d37.js.map