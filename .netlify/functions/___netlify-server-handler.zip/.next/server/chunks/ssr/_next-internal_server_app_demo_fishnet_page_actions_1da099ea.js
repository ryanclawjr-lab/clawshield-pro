module.exports=[192,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_demo_fishnet_page_actions_1da099ea.js.map